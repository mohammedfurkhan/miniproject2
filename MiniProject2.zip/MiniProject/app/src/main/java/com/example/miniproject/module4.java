package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class module4 extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module4);
        btn = findViewById(R.id.pdfview);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
        public void onClick(View v)
            {
                Intent i=new Intent(getApplicationContext(), pdfviewscreen.class);
                startActivity(i);
            }
        });
    }
}
